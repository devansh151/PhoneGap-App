$(document).ready(function(){
    app.initialize();
    $.material.init();
    $.material.ripples();
});